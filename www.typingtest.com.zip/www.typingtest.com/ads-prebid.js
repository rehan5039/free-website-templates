(function () {
    'use strict';
    window.canUseGVideo = true;
})();