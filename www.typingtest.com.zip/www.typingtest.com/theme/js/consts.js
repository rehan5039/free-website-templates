const INDEX_URL = "index.html";
const TEST_URL = "test.html";
const RESULT_URL = "result.html";
const BENCHMARK_URL = "benchmark.html";
const PRACTICE_URL = "practice.html";
const ANALYZE_URL = "analyze.html";
const TRAIN_URL = "/trainer/index.html";
const CERTIFICATE_URL = "certificate/certificate.html"