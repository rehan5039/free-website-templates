/** 
 * 
 * Date : 13 Feb 2023
 * Author : Ayman Amhijane (from Ashkev)
 * Portfolio : https://ashkev.netlify.app/
 * Github : https://github.com/ashkev-1
 * Name : TypingTest Pro 
 * Version : 1.0
 * Filename : quick-tour.js
 * Filepath : ./dist/assets/js/quick-tour.js
 * 
*/

/*************************/
// TABS (STEPS)

const quickTourSteps = document.querySelector('.quick-tour-steps-list');
const quickTourStepsItems = document.querySelectorAll('.quick-tour-steps-item');
const quickTourStepsContent = document.querySelectorAll('.quick-tour-steps-content');


// Initiale State
quickTourStepsItems.forEach(item => {
  if (item.classList.contains('active')) {
    item.classList.add('bg-white', 'shadow-lg', 'before:text-sky-500');

    // Get data-content-id attr
    const id = item.dataset.contentId;

    // Get active content element by id.
    const activeContentEl = document.getElementById(id);

    if (!activeContentEl) return;

    // Show active content
    activeContentEl.classList.remove('hidden');

  } else {
    item.classList.add('opacity-50');
  }
});


// Handler
quickTourSteps.addEventListener('click', (e) => {

  const target = e.target.closest('.quick-tour-steps-item');

  if (!target) return;

  // Active State

  // Remove active class
  quickTourStepsItems.forEach(item => {
    item.classList.remove('bg-white', 'shadow-lg', 'before:text-sky-500');
    item.classList.add('opacity-50');
  });

  // Add active class
  target.classList.add('bg-white', 'shadow-lg', 'before:text-sky-500');
  target.classList.remove('opacity-50');
  
  // Get Id
  const id = target.dataset.contentId;

  // Get step content element by id
  const stepContent = document.getElementById(id);

  if (!stepContent) return;

  // Hide all
  quickTourStepsContent.forEach(contentEl => contentEl.classList.add('hidden'));

  // Show the active one
  stepContent.classList.remove('hidden')

})