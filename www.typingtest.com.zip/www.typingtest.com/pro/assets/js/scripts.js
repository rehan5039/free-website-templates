/** 
 * 
 * Date : 13 Feb 2023
 * Author : Ayman Amhijane (from Ashkev)
 * Portfolio : https://ashkev.netlify.app/
 * Github : https://github.com/ashkev-1
 * Name : TypingTest Pro 
 * Version : 1.0
 * Filename : quick-tour.js
 * Filepath : ./dist/assets/js/quick-tour.js
 * 
*/

'use strict';


/*************************/
// PAGE LOADER

// Variables
const pageLoader = document.querySelector('.page-loader');
const pageLoadingTime = 400; // 1.5s

setTimeout(() => {
  pageLoader.classList.add('opacity-0');
}, pageLoadingTime);

pageLoader.classList.add('transition-opacity', 'duration-300');

const duration = getComputedStyle(pageLoader, null).transitionDuration.split(',')[0].replace('s', '') * 1000; // Convert seconds to milliseconds

setTimeout(() => pageLoader.classList.add('hidden'), (pageLoadingTime + duration));


window.addEventListener('DOMContentLoaded', () => {


  /*************************/
  // SIDEBAR

  // Variables
  const navMenu = document.querySelector('.nav-menu');
  const sidebarToggle = document.querySelector('.sidebar-toggle');
  const sidebarBackdrop = document.querySelector('.backdrop');

  const ASHKEVSidebar = (function () {
    return {

      // Init
      init() {
        navMenu.classList.remove('show');
        navMenu.classList.add('hide');
        navMenu.classList.add('max-xl:hidden');
        sidebarBackdrop.classList.add('hidden');
      },

      // Show Sidebar
      show() {
        navMenu.classList.add('show');
        navMenu.classList.remove('hide');
        navMenu.classList.remove('max-xl:hidden');
        sidebarBackdrop.classList.remove('hidden');
      },

      // Toggle Sidebar
      toggle() {
        this.show();
        sidebarBackdrop.addEventListener('click', (e) => this.init());
      }

    }
  })();

  // Sidebar Handlers
  sidebarToggle.addEventListener('click', (e) => ASHKEVSidebar.toggle());
  window.addEventListener('resize', (e) => ASHKEVSidebar.init());


  /*************************/
  // CAROUSEL


  // Intro
  const introSplideEl = document.querySelector('.intro-splide');
  const introOptions = {
    type: 'loop',
    snap: false,
    pauseOnHover: false,
    interval: 5000,
    autoplay: true
  }

  if (introSplideEl) {
    var introSplide = new Splide('.intro-splide', introOptions);
    introSplide.mount();
  }


  // Testimonial
  const testimonialSplideEl = document.querySelector('.testimonials-splide');
  const testimonialOptions = {
    type: 'loop',
    drag: 'free',
    perPage: 3,
  }

  if (testimonialSplideEl) {
    var testimonialSplide = new Splide('.testimonials-splide', testimonialOptions);
    testimonialSplide.mount();
  }
})