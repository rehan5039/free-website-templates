/** 
 * 
 * Date : 13 Feb 2023
 * Author : Ayman Amhijane (from Ashkev)
 * Portfolio : https://ashkev.netlify.app/
 * Github : https://github.com/ashkev-1
 * Name : TypingTest Pro 
 * Version : 1.0
 * Filename : faq.js
 * Filepath : ./dist/assets/js/faq.js
 * 
*/

/*************************/
// ACCORDION

window.addEventListener('DOMContentLoaded', () => {
  new Accordion('.test-takers-accordion', {
    duration: 250,
  }).open(0);

  new Accordion(['.technical-accordion', '.recruiters-accordion'], {
    duration: 250,
  });
});