//Selectors
const chunkExercises = document.getElementById("chunk-exercises");
const accuracyPercent = document.getElementById("accuracy-percent");
const accuracyTyped = document.getElementById("accuracy-typed");
const radialChartText = document.getElementById("radial-chart-text");
const descriptionIcon = document.getElementById('description-icon');
const chunkExercisesIcon = document.getElementById('chunk-exercises-icon');
const chunkAnalyzeIcon = document.getElementById('chunk-analyze-icon');
const chunkAccuracyIcon = document.getElementById('chunk-accuracy-icon');
const chunkSpeedIcon = document.getElementById('chunk-speed-icon');
const chunkLiftIcon = document.getElementById('chunk-lift-icon');
const chunkGeneralizeIcon = document.getElementById('chunk-generalize-icon');
const trainNowButton = document.getElementById('train-now');
const chunkButton = document.querySelector('.chunks-button');

const analyzeLink = document.getElementById('analyze-link');
const accuracyLink = document.getElementById('accuracy-link');
const speedLink = document.getElementById('speed-link');
const liftLink = document.getElementById('lift-link');
const comingSoonLink = document.getElementById('coming-soon-link');

const accuracyContainer = document.querySelector('.accuracy-container');
const speedContainer = document.querySelector('.speed-container');
const liftContainer = document.querySelector('.lift-container');
const comingSoonContainer = document.querySelector('.coming-soon-container');
const buttons = document.querySelectorAll('.interactions-wrapper-button');


const ANALYZE_URL = window.location.origin + "/bigram-blitz/analyze2/index.html";
const ANALYZECH_URL = window.location.origin + "/bigram-blitz/analyzech/index.html";
const ACCURACY_URL = window.location.origin + "/bigram-blitz/luggage4/index.html";
const SPEED_URL = window.location.origin + "/bigram-blitz/metronome4/index.html";
const LIFT_URL = window.location.origin + "/bigram-blitz/lifting3/index.html";
const SOON_URL = window.location.origin + "/bigram-blitz/receptionist5/index.html";
const CLOSE_URL = window.location.origin;



//Variables
const chunkNames = [
    "TH",
    "HE",
    "IN",
    "RE",
    "ER",
    "AN",
    "OU",
    "ON",
    "IS",
    "TO",
    "OR",
    "HA",
    "AT",
    "NG",
    "ED",
    "VE",
    "EN",
    "ES",
    "ST",
    "AR",
    "HI",
    "IT",
    "TE",
    "AS",
    "LL",
];
let totalChunks = new Array(chunkNames.length).fill(0);
let errorChunks = new Array(chunkNames.length).fill(0);

let selectedChunkIndex = 0;

const M = 5;

const _chunkArray = localStorage.getItem("chunkArray");
if (!_chunkArray) {
    localStorage.setItem("chunkArray", JSON.stringify(chunkNames));
}

const _totalChunks = localStorage.getItem('totalChunks');
if (!_totalChunks || JSON.parse(_totalChunks).every((el) => el === 0)) {
    localStorage.setItem('totalChunks', JSON.stringify(totalChunks));
    localStorage.setItem('errorChunks', JSON.stringify(errorChunks))
} else {
    totalChunks = JSON.parse(_totalChunks);
}

const _errorChunks = localStorage.getItem('errorChunks');
if (!_errorChunks || JSON.parse(_errorChunks).every((el) => el === 0)) {
    localStorage.setItem('errorChunks', JSON.stringify(errorChunks));
} else {
    errorChunks = JSON.parse(_errorChunks);
}

//Functions
function createChunkExercises() {
    let k = 0;
    const table = document.createElement("table");
    for (let i = 0; i < M; i++) {
        const row = document.createElement("tr");
        row.classList.add("chunk-row");
        for (let j = 0; j < M; j++) {
            const column = document.createElement("td");
            column.classList.add("chunk");

            if ((i + j) % 2) {
                column.classList.add("chunk-odd");
            } else {
                column.classList.add("chunk-even");
            }

            const canvas = document.createElement("canvas");
            canvas.setAttribute("class", "chunk-canvas");
            const chunkSpan = document.createElement("span");
            chunkSpan.classList.add("chunk-span");
            chunkSpan.innerText = chunkNames[k];
            column.addEventListener("click", () => {
                localStorage.setItem('selectedChunkIndex', JSON.stringify(chunkNames.indexOf(chunkSpan.innerText)))
                onChartClick(chunkSpan.innerText);
                selectedChunkIndex = chunkNames.indexOf(chunkSpan.innerText);
                chartInit(chunkNames.indexOf(chunkSpan.innerText));
            });

            const chunkDiv = document.createElement("div");
            chunkDiv.classList.add("chunk-div");
            chunkDiv.innerText = totalChunks[k];

            column.appendChild(chunkSpan);
            column.appendChild(chunkDiv);
            column.appendChild(canvas);
            row.appendChild(column);
            k++;
        }
        table.appendChild(row);
    }
    chunkExercises.appendChild(table);
    const spanText = document.createElement("a");
    spanText.classList.add("chunk-exercises-text", "clear-data", "over-anim");
    spanText.innerText = "Clear data";
    spanText.addEventListener('click', onClickClearData)
    chunkExercises.appendChild(spanText);
}

function onClickClearData() {
    localStorage.setItem('totalChunks', JSON.stringify(new Array(chunkNames.length).fill(0)));
    localStorage.setItem('errorChunks', JSON.stringify(new Array(chunkNames.length).fill(0)));
    clearChunkChart();
    refreshData();
    getData(0);
    chartInit(null);
    chunkChartInit();

    radialChartText.innerText = '--';
    accuracyTyped.innerText = '0';
    accuracyPercent.innerText = '%';
    clearCanvas();

    deAvtiveteInteractionsWrapper();
}

function refreshData() {
    totalChunks = JSON.parse(localStorage.getItem('totalChunks'));
    errorChunks = JSON.parse(localStorage.getItem('errorChunks'));
}

function clearCanvas() {
    let canvas = document.getElementById("radial-chart");
    if (canvas) canvas.remove();
    const canvasWrapper = document.querySelector('.radial-chart-container');
    canvas = document.createElement('canvas');
    canvas.setAttribute('id', 'radial-chart');
    canvas.setAttribute('width', '113');
    canvas.setAttribute('height', '113');
    canvasWrapper.prepend(canvas);
}

function chartInit(selectedChunkIndex) {
    if (!JSON.parse(sessionStorage.getItem('isThisFirstTime'))) {
        sessionStorage.setItem('isThisFirstTime', JSON.stringify('isThisFirstTime'));
    }

    const selectedChunkIndex1 = JSON.parse(localStorage.getItem('selectedChunkIndex'));

    if ((selectedChunkIndex === null || checkIfAllDataZero()) && !selectedChunkIndex1 && selectedChunkIndex1 !== 0) {
        radialChartText.innerText = '--';
        accuracyTyped.innerText = '0';
        accuracyPercent.innerText = '%';
        clearCanvas();
        return;
    }

    clearCanvas()
    const data = getData(selectedChunkIndex);

    if (data) {
        avtiveteInteractionsWrapper();
    } else {
        deAvtiveteInteractionsWrapper();
    }

    radialChartText.innerText = chunkNames[selectedChunkIndex];
    const ctx = document.getElementById("radial-chart").getContext("2d");
    const radialChart = new Chart(ctx, {
        type: "doughnut",
        data: {
            datasets: [{
                data: data,
                backgroundColor: ["#64eacb", "#fd889f"],
                borderColor: ["#1794ae"],
                borderWidth: 0,
            },],
        },
        options: {
            scales: {},
            plugins: {
                tooltip: {
                    enabled: true,
                    callbacks: {
                        label: function (tooltipItem) {
                            if (tooltipItem.parsed === data[0]) {
                                return ((data[0] / (data[0] + data[1])) * 100).toFixed(1);
                            } else if (tooltipItem.parsed === data[1]) {
                                return ((data[1] / (data[0] + data[1])) * 100).toFixed(1);
                            }
                        },
                    },
                },
            },
        },
    });

    let percent = ((data[0] / (data[0] + data[1])) * 100).toFixed(1) + "%";
    if (data[0] === 0) accuracyPercent.innerText = 0 + '%'
    else accuracyPercent.innerText = percent

    accuracyTyped.innerText = (data[0] + data[1]);
}

function avtiveteInteractionsWrapper() {
    buttons.forEach((button) => {
        button.classList.add('primary-background');
        button.classList.remove('buttonDisabled')
    })
    accuracyContainer.classList.add('unopacity');
    speedContainer.classList.add('unopacity');
	liftContainer.classList.add('unopacity');
    comingSoonContainer.classList.add('unopacity');
}

function deAvtiveteInteractionsWrapper() {
    console.log('deactivated');
    buttons.forEach((button, index) => {
        if (index !== 0) {
            button.classList.add('buttonDisabled')
        }
        button.classList.remove('primary-background');
    })
    accuracyContainer.classList.remove('unopacity');
    speedContainer.classList.remove('unopacity');
	liftContainer.classList.remove('unopacity');
    comingSoonContainer.classList.remove('unopacity');
}

function clearChunkChart() {
    let canvas = document.querySelectorAll(".chunk-canvas");
    const chunkDiv = document.querySelectorAll(".chunk-div");
    if (canvas) {
        canvas.forEach((can) => can.remove())
    }
    const canvasWrapper = document.querySelectorAll('.chunk');
    canvasWrapper.forEach((canva, i) => {
        chunkDiv[i].innerText = '0'
        canvas = document.createElement('canvas');
        canvas.setAttribute('class', 'chunk-canvas');
        canva.appendChild(canvas);
    })


}

function checkIfAllDataZero() {

    const totalChunksForCheck = JSON.parse(localStorage.getItem('totalChunks'));
    const errorChunksForCheck = JSON.parse(localStorage.getItem('errorChunks'));

    const totalChunksAllZero = totalChunksForCheck.every(item => item === 0);

    const errorChunksAllZero = errorChunksForCheck.every(item => item === 0);

    if (totalChunksAllZero && errorChunksAllZero) {
        return true;
    }
    return false
}

function chunkChartInit() {
    const ctx = document.querySelectorAll(".chunk-canvas");
    ctx.forEach((canvas, i) => {
        canvas.getContext("2d");
        const radialChart = new Chart(canvas, {
            type: "doughnut",
            data: {
                datasets: [{
                    data: [totalChunks[i], errorChunks[i]],
                    backgroundColor: ["#64eacb", "#fd889f"],
                    borderColor: ["#1794ae"],
                    borderWidth: 0,
                    hoverBackgroundColor: ["#64eacb", "#fd889f"],
                },],
            },
            options: {
                scales: {},
                plugins: {
                    tooltip: {
                        enabled: false,
                    },
                },
            },
        });
    });
}

function getData(selectedChunkIndex) {
    const _greenFill = (totalChunks[selectedChunkIndex] - errorChunks[selectedChunkIndex]);
    const _redFill = errorChunks[selectedChunkIndex];

    const allZero = checkIfAllDataZero();
    const url = new URL(ANALYZECH_URL);
    url.searchParams.append("chunk", chunkNames[selectedChunkIndex]);
    analyzeLink.setAttribute('href', url);

    if (allZero) {
        let url = new URL(ACCURACY_URL);
        trainNowButton.setAttribute('href', url);
    }
    else if (((_greenFill - _redFill) / _greenFill) * 100 >= 90) {
        let url = new URL(SPEED_URL);
        url.searchParams.append("chunk", chunkNames[selectedChunkIndex]);
        trainNowButton.setAttribute('href', url);
    } else {
        let url = new URL(ACCURACY_URL);
        url.searchParams.append("chunk", chunkNames[selectedChunkIndex]);
        trainNowButton.setAttribute('href', url);
    }

    return [_greenFill, _redFill];
}

function onChartClick(chunkName) {
    radialChartText.innerText = chunkName;
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}

function setAttributes() {
    accuracyLink.setAttribute('href', ACCURACY_URL);
    speedLink.setAttribute('href', SPEED_URL);
	liftLink.setAttribute('href', LIFT_URL);
    comingSoonLink.setAttribute('href', SOON_URL);

    chunkButton.addEventListener('click', () => {
        document.querySelector(".clear-data").scrollIntoView();
    })

    descriptionIcon.setAttribute('title', 'The training program stands on a fact, that words consist of different letter combinations - Bigrams. We have selected the 25 most common Bigrams in English language and help you to train the motoric path for typing each Bigram. When you scroll to the bottom of the page, you’ll find the Bigram specific data and you can select different Bigrams for practice. Remember, that when you are training for a new skill, returning regularly to the practices, will improve you the most. See you tomorrow!!')
    chunkExercisesIcon.setAttribute('title', 'Bigrams are letter combinations that make up every word. Bigrams include bigrams for two letters, trigrams for three and so on. Research suggests that you can increase both typing accuracy and speed by training the most common bigrams. The gain is relatively small per bigram but by training multiple ones, like the top 25 most common bigrams, the benefits build up.')
	chunkAnalyzeIcon.setAttribute('title', 'First the training program analyzes your typing for the two bigrams that cause the most trouble on the population level: HA and OR. Even the program starts from these two, your personal proficiency for all 25 Bigrams is updated after every training at the site. During the analyze, please type the given words as accurately as possible. Don’t mind if you make a mistake, there is no need for correction as the word will be counted as something that caused friction for any reason.')
	chunkAccuracyIcon.setAttribute('title', 'What makes the most friction during typing? Correcting the errors!! A need to use backspace cuts your thought and slows you down. The first thing to learn for smooth typing is to make as little mistakes as possible. Our protocol for accuracy practice stands on a finding, that one learns better when they make about 15% errors (thus there is the pressure element in the practice). When brain gets notified that something was not correct, it “understands” that the behavior needs to be altered. Once you reach the 95% accuracy, it’s time to move on to build up the speed.')
	chunkSpeedIcon.setAttribute('title', 'First things first - The speed itself is not the key in this practice. Studies show that the typing rhythm correlates well with smooth typing. Instead of typing in bursts, try to keep a steady pace.')
	chunkLiftIcon.setAttribute('title', 'Time to try how fast can you type?')
	chunkGeneralizeIcon.setAttribute('title', 'We suppose, that the most of us are not practicing the typing skill just to impress, but to have a smooth way of working while typing. The last phase of the training program is to move the gained skills to your everyday life.')

}

function hamburgerToggle() {
    const ham = document.querySelector('.hamburger')
    const mobList = document.querySelector('.mob-list')
    ham.addEventListener('click', () => {

        if (ham.classList.contains('open')) ham.classList.remove('open')
        else ham.classList.add('open')

        if (mobList.style.display === 'block') mobList.style.display = 'none'
        else mobList.style.display = 'block'
    })
}

window.onload = () => {
    const selectedChunkIndex = JSON.parse(localStorage.getItem('selectedChunkIndex'));

    if (!selectedChunkIndex) {
        let url = new URL(ANALYZECH_URL);
        trainNowButton.setAttribute('href', url);

        const urlStart = new URL(ANALYZE_URL);
        analyzeLink.setAttribute('href', urlStart);
    }

    if (JSON.parse(sessionStorage.getItem('isThisFirstTime'))) {
        chartInit(selectedChunkIndex);
        return;
    }

    const totalChunks = JSON.parse(localStorage.getItem('totalChunks'));
    const errorChunks = JSON.parse(localStorage.getItem('errorChunks'));

    let minAcc = Infinity;
    let minAccuracyIndex;

    if (!checkIfAllDataZero()) {
        totalChunks.forEach((data, index) => {
            let accuracy = ((data / (data + errorChunks[index])) * 100).toFixed(1);
            console.log(accuracy);
            if (accuracy < minAcc) {
                minAcc = accuracy;
                minAccuracyIndex = index;
            }
        })

        localStorage.setItem('selectedChunkIndex', minAccuracyIndex)
        chartInit(minAccuracyIndex)

        return;
    }

    localStorage.setItem('selectedChunkIndex', null)
    chartInit(null)
}

//Function Calling
createChunkExercises();
chunkChartInit();
setAttributes();
hamburgerToggle();
