const tipsRuleId = {
  Benchmark: "bench_promo",
  Trainer: "trainer_promo",
  Easy: "easy_promo",
  Certificate: "certificate_promo",
  Challenge: "challenge_promo",
  CapsLock: "caps_lock_promo",
  WarmUp: "warm_up_promo",
  SlowDown: "slow_down_promo",
  LShift: "left_shift_promo",
  RShift: "right_shift_promo",
  Tomorrow: "tomorrow_promo",
}

const TIPS = [
  {
    ruleID: tipsRuleId.Benchmark,
    title: "Compare Your Skills",
    message: "See how you compare <br /> to other test takers",
    buttonText: "Benchmark",
    buttonLink: "window.location.href = BENCHMARK_URL + window.location.search;",
  },
  {
    ruleID: tipsRuleId.Trainer,
    title: "How About Training?",
    message: "With touch typing your <br /> typing speed could be",
    buttonText: "Train now",
    buttonLink: "window.location.href = TRAIN_URL;",
  },
  {
    ruleID: tipsRuleId.Easy,
    title: "Take It Easy?",
    message: "How about trying a <br /> text that is easier",
    buttonText: "Easy test",
    buttonLink: "sessionStorage.setItem('text_name', 'easyText');sessionStorage.setItem('timer', 1);window.location.href = INDEX_URL;",
  },
  {
    ruleID: tipsRuleId.Certificate,
    textName: "certificate.txt",
    title: "Prove You Skills",
    message: "Take an advanced test <br /> for a typing certificate",
    buttonText: "Certificate",
    buttonLink: "window.location.href = INDEX_URL;",
  },
  {
    ruleID: tipsRuleId.Challenge,
    title: "You are Fast!!",
    icon: "fas fa-handshake fa-4x",
    message: "See how well your friend <br/> does against your score!",
    buttonText: "Challenge",
    buttonLink: "window.location.href = CHALLENGE_URL;",
  },
  {
    ruleID: tipsRuleId.CapsLock,
    title: "No Cap!",
    icon: "fas fa-hat-wizard fa-4x",
    message: "Press Shift+key at the same time for a Capital letter!",
    buttonText: "NEW TEST",
    buttonLink: "window.location.href = INDEX_URL;",
  },
  {
    ruleID: tipsRuleId.WarmUp,
    title: "Warm-up fingers",
    icon: "fas fa-solid fa-hand-sparkles fa-4x",
    message: "For the best WPM, run several test rounds!",
    buttonText: "NEW TEST",
    buttonLink: "window.location.href = INDEX_URL;",
  },
  {
    ruleID: tipsRuleId.SlowDown,
    title: "Slow Down!",
    icon: "fas fa-solid fa-gauge-high fa-4x",
    message: "Concentrate on typing pace and focus on accuracy",
    buttonText: "NEW TEST",
    buttonLink: "window.location.href = INDEX_URL;",
  },
  {
    ruleID: tipsRuleId.LShift,
    title: "Train for Left Shift.",
    message: "Try using the shift key with your opposite hand when typing. For example, if you usually press the shift key with your right hand, experiment with using your left hand instead. This can help distribute the workload between your hands and potentially improve your typing speed and accuracy.",
    buttonText: "NEW TEST",
    buttonLink: "window.location.href = INDEX_URL;",
  },
  {
    ruleID: tipsRuleId.RShift,
    title: "Train for Right Shift.",
    message: "Try using the shift key with your opposite hand when typing. For example, if you usually press the shift key with your right hand, experiment with using your left hand instead. This can help distribute the workload between your hands and potentially improve your typing speed and accuracy.",
    buttonText: "NEW TEST",
    buttonLink: "window.location.href = INDEX_URL;",
  },
  {
    ruleID: tipsRuleId.Tomorrow,
    title: "See you Tomorrow!",
    icon: "fas fa-solid fa-calendar-days fa-3x",
    message: "Testing your typing speed regularly improves your overall typing",
    buttonText: "NEW TEST",
    buttonLink: "window.location.href = INDEX_URL;",
  }
];

function tipOnClick(tipName) {
  return () => {
    window.dataLayer.push({
      'event': 'tip_clicked',
      'tip_name': tipName,
      'tip_type': 'static' // ai tips get 'tip_type':'ai'
    })
  }
}

function getSeenTips() {
  let lastSeenTips = [];
  const lastSeenTipsStr = localStorage.getItem(LAST_PROMO);
  if (lastSeenTipsStr) {
    lastSeenTips = lastSeenTipsStr.split(",");
  }
  
  return { lastSeenTip: lastSeenTips[lastSeenTips.length - 1], lastSeenTips };
}

function saveSeenTips(lastTip, tipsCount) {
  let { lastSeenTips: lastSeenTipsLimited } = getSeenTips();
  if (lastSeenTipsLimited.length >= tipsCount - 1) {
    lastSeenTipsLimited = lastSeenTipsLimited.slice(lastSeenTipsLimited.length - tipsCount - 1);
  }

  lastSeenTipsLimited = lastSeenTipsLimited.filter(tip => tip !== lastTip);
  lastSeenTipsLimited.push(lastTip);

  const lastSeenTipsStr = lastSeenTipsLimited.join(",");
  localStorage.setItem(LAST_PROMO, lastSeenTipsStr);
}

function getTipKey(ruleId) {
  const tipKey = Object.keys(tipsRuleId).find(key => tipsRuleId[key] === ruleId);
  return tipKey;
}

const DEFAULT_PROMO = "default_promo";
const LAST_PROMO = "lastPromo";
const EASY_DATE = "easyDate";
const showTip = (tipsRules) => {
  let { lastSeenTips } = getSeenTips();
  lastSeenTips = lastSeenTips.reverse();
  const rulesFiltered = tipsRules
    .filter((rule) => !!rule.condition)
    .sort((a, b) => a.priority - b.priority);
  const rules = rulesFiltered.sort((a, b) => {
      if (lastSeenTips.length === 0) {
        return 0;
      }

      if (lastSeenTips.length === 1) {
        if (lastSeenTips.indexOf(b.ruleID) === 0) {
          return -1;
        }
        return 0;
      }

      let aIndex = lastSeenTips.indexOf(a.ruleID);
      let bIndex = lastSeenTips.indexOf(b.ruleID);

      if (aIndex === -1) {
        aIndex = rulesFiltered.length;
      }
      if (bIndex === -1) {
        bIndex = rulesFiltered.length;
      }

      return bIndex - aIndex;
    });

  const tipEl = document.getElementById(DEFAULT_PROMO);
  // tipEl.style.display = "block";

  if (rules.length === 0 || !tipEl) {
    return;
  }

  const ruleId = rules[0].ruleID;
  
  const tip = TIPS.find((tip) => tip.ruleID === ruleId);

  
  if (!tip) {
    return;
  }

  const tipKey = getTipKey(ruleId);

  tipEl.classList.add(ruleId);
  tipEl.querySelector("h2").innerText = tip.title;
  tipEl.querySelector("p.message-before-content-image").innerHTML = tip.message;
  tipEl.querySelector("p.message-after-content-image").innerHTML = tip.message;
  if (tip.icon) {
    tipEl.querySelector(".content-fa i").classList = tip.icon;
  }
  const button = tipEl.querySelector("button");
  button.innerText = tip.buttonText;
  button.setAttribute("onClick", tip.buttonLink);
  if (tip.textName) {
    button.addEventListener("click", () => {
      sessionStorage.setItem("text_name", tip.textName);
    })
  }
  button.addEventListener("click", tipOnClick(tipKey));
  tipEl.style.display = "block";

  saveSeenTips(ruleId, TIPS.length)

  if (ruleId === tipsRuleId.Easy) {
    localStorage.setItem(EASY_DATE, String(Date.now()));
  }

  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push({
  'event': 'tip_seen', //static
  'tip_name': tipKey,
  'tip_type': 'static' // ai tips get 'tip_type':'ai'
  })
}
