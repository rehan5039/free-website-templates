/**
 * Based on Mattias Fjellvang script - 
 * https://constantsolutions.dk/2020/06/delay-loading-of-google-analytics-google-tag-manager-script-for-better-pagespeed-score-and-initial-load/
 *  
 */
var TAGMANAGER_HOST = 'www.googletagmanager.com';
var TAGMANAGER_CONTAINER_ID = 'GTM-W4KVSHS';
var TAGMANAGER_TIMEOUT = 2000;

var initGTMOnEvent = function(a) {
  initGTM();
  a.currentTarget.removeEventListener(a.type, initGTMOnEvent);
}, initGTM = function() {
  if (window.gtmDidInit) {
    return !1;
  }
  window.gtmDidInit = !0;
  var a = document.createElement("script");
  a.type = "text/javascript";
  a.async = !0;
  a.onload = function() {
    dataLayer.push({event:"gtm.js", "gtm.start":(new Date()).getTime(), "gtm.uniqueEventId":0,});
  };
  a.src = `https://${TAGMANAGER_HOST}/gtm.js?id=${TAGMANAGER_CONTAINER_ID}`;
  document.head.appendChild(a);
};
document.addEventListener("DOMContentLoaded", function() {
  setTimeout(initGTM, TAGMANAGER_TIMEOUT);
});
document.addEventListener("scroll", initGTMOnEvent);
document.addEventListener("mousemove", initGTMOnEvent);
document.addEventListener("touchstart", initGTMOnEvent);