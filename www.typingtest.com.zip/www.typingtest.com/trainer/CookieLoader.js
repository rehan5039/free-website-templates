function CookieLoader() {
	var _this = this;

_this._sObj = null;
_this._name = "TTTMMM";

//"TyMa_sa_" + courseId + lessonId + lessonName + "7785"
//TyMa_sa_TMIT3-uk-0003A001Touch Typing Intro & Simulator7785

_this._d_completedExs = [];
_this._d_interruptedExs = [];
_this._d_failedExs = [];
_this._d_scores = [];
_this._d_interruptedScores = [];
_this._d_lessonLocation = -1;
_this._d_lessonStatus = "";

_this.init2 = function init2(value) {
			_this._name = value;
}

_this.error = function error(value) {
			console.log(value);
}

_this.loadSettings = function loadSettings() {
			_this._sObj = CookieCl.getCookie(_this._name);
			if (_this._sObj != null) {
				_this._sObj = _this._sObj.toString();
				if (_this._sObj.length > 0) {
					if (_this._sObj == "error") {
						_this.error("load settings error 2: function loadSettings(), SharedObject is null");
					}
					else {
						_this.getData();
					}
				}
			}
			else {
				_this.error("load settings error: function loadSettings(), SharedObject is null");
			}
			
}

    _this.trim = function trim(original) {
        var characters = original.split("");
        for (var i = 0; i < characters.length; i++) {
            if (_this.isWhitespace(characters[i])) {
                characters.splice(i, 1);
                i--;
            }
            else {
                break;
            }
        }
        for (i = characters.length - 1; i >= 0; i--) {
            if (_this.isWhitespace( characters[i])) {
                characters.splice( i, 1 );
            }
            else {
                break;
            }
        }
        return characters.join("");
    }

    _this.isWhitespace = function isWhitespace(ch) {
        return  ch == '\r' ||
            ch == '\n' ||
            ch == '\f' ||
            ch == '\t' ||
            ch == ' ';
    }
		
_this.getData = function getData() {
			if (_this._sObj) {
				var mm1 = "[completedExs:";
				var mm001 = "[interruptedExs:";
				var mm2 = "[failedExs:";
				var mm3 = "[scores:";
				var mm4 = "[interruptedScores:";
				var mmLL = "[lessonLocation:";
				var mmSS = "[lessonStatus:";
				
				var index1 = _this._sObj.indexOf(mm1);
				var index001 = _this._sObj.indexOf(mm001);
				var index2 = _this._sObj.indexOf(mm2);
				var index3 = _this._sObj.indexOf(mm3);
				var index4 = _this._sObj.indexOf(mm4);
				var indexLL = _this._sObj.indexOf(mmLL);
				var indexSS = _this._sObj.indexOf(mmSS);
				
				var cStr = "";
				var ieStr = "";
				var fStr = "";
				var sStr = "";
				var iStr = "";
				var LLStr = "";
				var SSStr = "";
				
				if (index1 != -1) {
					for (var k1 = (index1 + mm1.length); k1 < _this._sObj.length; k1 ++) {
						var char1 = _this._sObj.charAt(k1);
						if (char1 != "]") {
							cStr = cStr + char1;
						}
						else {
							break;
						}
					}
				}
				if (index001 != -1) {
					for (var k001 = (index001 + mm001.length); k001 < _this._sObj.length; k001 ++) {
						var char001 = _this._sObj.charAt(k001);
						if (char001 != "]") {
							ieStr = ieStr + char001;
						}
						else {
							break;
						}
					}
				}
				if (index2 != -1) {
					for (var k2 = (index2 + mm2.length); k2 < _this._sObj.length; k2 ++) {
						var char2 = _this._sObj.charAt(k2);
						if (char2 != "]") {
							fStr = fStr + char2;
						}
						else {
							break;
						}
					}
				}
				if (index3 != -1) {
					for (var k3 = (index3 + mm3.length); k3 < _this._sObj.length; k3 ++) {
						var char3 = _this._sObj.charAt(k3);
						if (char3 != "]") {
							sStr = sStr + char3;
						}
						else {
							break;
						}
					}
				}
				if (index4 != -1) {
					for (var k4 = (index4 + mm4.length); k4 < _this._sObj.length; k4 ++) {
						var char4 = _this._sObj.charAt(k4);
						if (char4 != "]") {
							iStr = iStr + char4;
						}
						else {
							break;
						}
					}
				}
				if (indexLL != -1) {
					for (var kLL = (indexLL + mmLL.length); kLL < _this._sObj.length; kLL ++) {
						var charLL = _this._sObj.charAt(kLL);
						if (charLL != "]") {
							LLStr = LLStr + charLL;
						}
						else {
							break;
						}
					}
				}
				if (indexSS != -1) {
					for (var kSS = (indexSS + mmSS.length); kSS < _this._sObj.length; kSS ++) {
						var charSS = _this._sObj.charAt(kSS);
						if (charSS != "]") {
							SSStr = SSStr + charSS;
						}
						else {
							break;
						}
					}
				}
				
				cStr = _this.trim(cStr);
				ieStr = _this.trim(ieStr);
				fStr = _this.trim(fStr);
				sStr = _this.trim(sStr);
				iStr = _this.trim(iStr);
				LLStr = _this.trim(LLStr);
				SSStr = _this.trim(SSStr);
				
				if (cStr.length > 0) {
					_this._d_completedExs = cStr.split(",");
					for (var i6 = 0; i6 < _this._d_completedExs.length; i6 ++) {
						_this._d_completedExs[i6] = Number(_this._d_completedExs[i6]);
					}
				}
				else {
					_this._d_completedExs = [];
				}
				
				
				if (ieStr.length > 0) {
					_this._d_interruptedExs = ieStr.split(",");
					for (var i88 = 0; i88 < _this._d_interruptedExs.length; i88 ++) {
						_this._d_interruptedExs[i88] = Number(_this._d_interruptedExs[i88]);
					}
				}
				else {
					_this._d_interruptedExs = [];
				}
				
				if (fStr.length > 0) {
					_this._d_failedExs = fStr.split(",");
					for (var i99 = 0; i99 < _this._d_failedExs.length; i99 ++) {
						_this._d_failedExs[i99] = Number(_this._d_failedExs[i99]);
					}
				}
				else {
					_this._d_failedExs = [];
				}
				
				
				if (sStr.length > 0) {
					_this._d_scores = sStr.split(",");
					for (var i998 = 0; i998 < _this._d_scores.length; i998 ++) {
						_this._d_scores[i998] = Number(_this._d_scores[i998]);
					}
				}
				else {
					_this._d_scores = [];
				}

				
				if (iStr.length > 0) {
					_this._d_interruptedScores = iStr.split(",");
					for (var igggg = 0; igggg < _this._d_interruptedScores.length; igggg ++) {
						_this._d_interruptedScores[igggg] = Number(_this._d_interruptedScores[igggg]);
					}
				}
				else {
					_this._d_interruptedScores = [];
				}
				
				
				if (LLStr.length > 0) {
					_this._d_lessonLocation = Number(LLStr);
				}
				else {
					_this._d_lessonLocation = -1;
				}
				
				if (SSStr.length > 0) {
					_this._d_lessonStatus = SSStr;
				}
				else {
					_this._d_lessonStatus = "";
				}

			}
			else {
				_this.error("getData settings error: function getData(), _sObj is null");
			}
		}
	
}