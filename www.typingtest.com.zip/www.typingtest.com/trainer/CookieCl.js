﻿var CookieCl = new Object();

CookieCl.useLocalStorage = true;

CookieCl.getCookie = function getCookie(name) {
  var orig_name = name;
  name = encodeURIComponent(name);
  var matches = "";
  try {
	  matches = document.cookie.match(new RegExp(
		"(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
	  ));
  }
  catch (err) {
	  matches2 = "";
  }
  var matches2 = "";
  if ((matches == null) || (matches == undefined)) {
	  matches2 = "";
  }
  else {
	  try {
		matches2 = decodeURIComponent(matches[1]);
	  }
	  catch (err) {
		matches2 = "";
	  }
  }
  if ((matches2 == null) || (matches2 == undefined)) {
	  matches2 = "";
  }
  
  //------------------------------
  if (CookieCl.useLocalStorage) {
	  if (matches2 == '') {
			CookieCl.setCookie(orig_name, 'deleted', true);
			matches2 = '';
			try {
				matches2 = localStorage.getItem(name);
			}
			catch (err) {
				matches2 = '';
			}
			if ((matches2 == null) || (matches2 == undefined)) {
				matches2 = "";
			}
			try {
				matches2 = decodeURIComponent(matches2);
			}
			catch (err) {
				matches2 = "";
			}
	  }
	  else if (matches2 == 'deleted') {
			matches2 = '';
			try {
				matches2 = localStorage.getItem(name);
			}
			catch (err) {
				matches2 = '';
			}
			if ((matches2 == null) || (matches2 == undefined)) {
				matches2 = "";
			}
			try {
				matches2 = decodeURIComponent(matches2);
			}
			catch (err) {
				matches2 = "";
			}
	  }
	  else {
		  CookieCl.setCookie(orig_name, 'deleted', true);
		  CookieCl.setCookie(orig_name, matches2);
	  }
  }
  return matches2;
}

/*

options:

expires
Ð’Ñ€ÐµÐ¼Ñ Ð¸ÑÑ‚ÐµÑ‡ÐµÐ½Ð¸Ñ cookie. Ð˜Ð½Ñ‚ÐµÑ€Ð¿Ñ€ÐµÑ‚Ð¸Ñ€ÑƒÐµÑ‚ÑÑ Ð¿Ð¾-Ñ€Ð°Ð·Ð½Ð¾Ð¼Ñƒ, Ð² Ð·Ð°Ð²Ð¸ÑÐ¸Ð¼Ð¾ÑÑ‚Ð¸ Ð¾Ñ‚ Ñ‚Ð¸Ð¿Ð°:
Ð§Ð¸ÑÐ»Ð¾ â€“ ÐºÐ¾Ð»Ð¸Ñ‡ÐµÑÑ‚Ð²Ð¾ ÑÐµÐºÑƒÐ½Ð´ Ð´Ð¾ Ð¸ÑÑ‚ÐµÑ‡ÐµÐ½Ð¸Ñ. ÐÐ°Ð¿Ñ€Ð¸Ð¼ÐµÑ€, expires: 3600 â€“ ÐºÑƒÐºÐ° Ð½Ð° Ñ‡Ð°Ñ.
ÐžÐ±ÑŠÐµÐºÑ‚ Ñ‚Ð¸Ð¿Ð° Date â€“ Ð´Ð°Ñ‚Ð° Ð¸ÑÑ‚ÐµÑ‡ÐµÐ½Ð¸Ñ.
Ð•ÑÐ»Ð¸ expires Ð² Ð¿Ñ€Ð¾ÑˆÐ»Ð¾Ð¼, Ñ‚Ð¾ cookie Ð±ÑƒÐ´ÐµÑ‚ ÑƒÐ´Ð°Ð»ÐµÐ½Ð¾.
Ð•ÑÐ»Ð¸ expires Ð¾Ñ‚ÑÑƒÑ‚ÑÑ‚Ð²ÑƒÐµÑ‚ Ð¸Ð»Ð¸ 0, Ñ‚Ð¾ cookie Ð±ÑƒÐ´ÐµÑ‚ ÑƒÑÑ‚Ð°Ð½Ð¾Ð²Ð»ÐµÐ½Ð¾ ÐºÐ°Ðº ÑÐµÑÑÐ¸Ð¾Ð½Ð½Ð¾Ðµ Ð¸ Ð¸ÑÑ‡ÐµÐ·Ð½ÐµÑ‚ Ð¿Ñ€Ð¸ Ð·Ð°ÐºÑ€Ñ‹Ñ‚Ð¸Ð¸ Ð±Ñ€Ð°ÑƒÐ·ÐµÑ€Ð°.

path
ÐŸÑƒÑ‚ÑŒ Ð´Ð»Ñ cookie.

domain
Ð”Ð¾Ð¼ÐµÐ½ Ð´Ð»Ñ cookie.

secure
Ð•ÑÐ»Ð¸ true, Ñ‚Ð¾ Ð¿ÐµÑ€ÐµÑÑ‹Ð»Ð°Ñ‚ÑŒ cookie Ñ‚Ð¾Ð»ÑŒÐºÐ¾ Ð¿Ð¾ Ð·Ð°Ñ‰Ð¸Ñ‰ÐµÐ½Ð½Ð¾Ð¼Ñƒ ÑÐ¾ÐµÐ´Ð¸Ð½ÐµÐ½Ð¸ÑŽ.

*/

CookieCl.setCookie = function setCookie(name, value, toCookie) {
	name = encodeURIComponent(name);
	
	toCookie = toCookie || false;
	
	if (CookieCl.useLocalStorage) {
		if (!toCookie) {
			try {
				var nn_value = encodeURIComponent(value);
				localStorage.setItem(name, nn_value);
			}
			catch (err) {
				return "error";
			}
			return "";
		}
	}
	
	//-------------------------------------------------
  
  var date = new Date;
  date.setDate(date.getDate() + 365);
  return CookieCl.setCookie2(name, value, {expires: date.toUTCString(), path: '/'});
}

CookieCl.setCookie2 = function setCookie2(name, value, options) {
  try {
	  options = options || {};
	
	  var expires = options.expires;
	
	  if (typeof expires == "number" && expires) {
		var d = new Date();
		d.setTime(d.getTime() + expires * 1000);
		expires = options.expires = d;
	  }
	  if (expires && expires.toUTCString) {
		options.expires = expires.toUTCString();
	  }
	
	  value = encodeURIComponent(value);
	
	  var updatedCookie = name + "=" + value;
	
	  for (var propName in options) {
		updatedCookie += "; " + propName;
		var propValue = options[propName];
		if (propValue !== true) {
		  updatedCookie += "=" + propValue;
		}
	  }
	
	  document.cookie = updatedCookie;
  }
  catch (err) {
	  return "error";
  }
  return "";
}

CookieCl.deleteCookie = function deleteCookie(name) {
  return CookieCl.setCookie2(name, "", {
    expires: -1
  });
}