/* Copyright TypingMaster, Inc. */

var showTimeout = 100;
var hideTimeout = 500;

var timeouts = new Array();

function show(id) {
    if (timeouts[id] != null) {
        window.clearTimeout(timeouts[id]);
    }
    timeouts[id] = setTimeout('doShow(\'' + id + '\')', showTimeout);
}
function hide(id) {
    if(timeouts[id] != null) {
        window.clearTimeout(timeouts[id]);
    }
    timeouts[id] = setTimeout('doHide(\'' + id + '\')', hideTimeout);
}
function showNow(id) {
    if (timeouts[id] != null) {
        window.clearTimeout(timeouts[id]);
    }
    doShow(id);
}
function hideNow(id) {
    if(timeouts[id] != null) {
        window.clearTimeout(timeouts[id]);
    }
    doHide(id);
}

function doShow(id) {
    hideAll();
    document.getElementById(id).style.visibility = "visible";
}
function doHide(id) {
    document.getElementById(id).style.visibility = "hidden";
}

function hideAll() {
    for (i = 0; i <= 5; ++i) {
        menuname = 'menu' + i;
        if(timeouts[menuname] != null) {
            window.clearTimeout(timeouts[menuname]);
        }
        
        var temp1 = document.getElementById(menuname);
        if (temp1 != null) {
            temp1.style.visibility = "hidden";
        }
        
    }
}
/* not used
function selectMenuItem(menuName) {
    var menuDiv =  document.getElementById("menu");
    
    var children = menuDiv.getElementsByTagName("p");
    for (i = 0; i < children.length; ++i) {
        children.item(i).style.backgroundColor = "transparent";
    }
    document.getElementById("menu_" + menuName).style.backgroundColor = "#CAF789";
}
*/

/* Functions for making popup windows */
function openPopup(url, name, width, height, x, y, addprops) {
    if(addprops == null) {
        addprops = "";
    }
    if(url == null || url == "") {
        return false;
    }
    else {
        myWindow = window.open(url, name,'width='+width+',height='+height+',screenX='+x+',screenY='+y+',left='+x+',top='+y+',resizable=yes,scrollbars=yes'+addprops);
        myWindow.focus();
        return false;
    }
}

function formPopup(form, name, width, height, x, y, addprops) {
    return openPopup(form.go[form.go.selectedIndex].value, name, width, height, x, y, addprops);
}
function doLoad() {
}
function getEl(elementName) {
    var elem;
    if (document.getElementById) {
        elem = document.getElementById(elementName);
    }
    else if(document.all) {
        elem = document.all[elementName];
    }
    
    if (elem != null) {
        return elem;
    }
    else { //fall back
        return document.getElementsByName(elementName)[0];
    }
}
function getBrowserWidth() {
	// the more standards compliant browsers (mozilla/netscape/opera/IE7) use window.innerWidth and window.innerHeight
	if (typeof window.innerWidth != 'undefined') {
		  return window.innerWidth;
	}
	// IE6 in standards compliant mode (i.e. with a valid doctype as the first line in the document)
	else if (typeof document.documentElement != 'undefined' && 
			  typeof document.documentElement.clientWidth != 'undefined' && 
			  document.documentElement.clientWidth != 0) {
		return document.documentElement.clientWidth;
	}
	 // older versions of IE
	else {
		return document.getElementsByTagName('body')[0].clientWidth;
	}
}
function getBrowserHeight() {
	// the more standards compliant browsers (mozilla/netscape/opera/IE7) use window.innerHeight and window.innerHeight
	if (typeof window.innerHeight != 'undefined') {
		  return window.innerHeight;
	}
	// IE6 in standards compliant mode (i.e. with a valid doctype as the first line in the document)
	else if (typeof document.documentElement != 'undefined' && 
			  typeof document.documentElement.clientHeight != 'undefined' && 
			  document.documentElement.clientHeight != 0) {
		return document.documentElement.clientHeight;
	}
	 // older versions of IE
	else {
		return document.getElementsByTagName('body')[0].clientHeight;
	}
}
